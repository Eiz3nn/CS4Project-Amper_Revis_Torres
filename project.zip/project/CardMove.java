package project;

import java.util.ArrayList;

public class CardMove extends Card {
    private int posChange, posSet;
    private static ArrayList<CardMove> deckCardMove = new ArrayList<CardMove>();
    
    public CardMove(String d, String e, String c, int i, int C, int s){
        super(d,e,c," cardmove",i);
        posChange = C;
        posSet = s;
        deckCardMove.add(this);
        
        
    }

    /**
     * @return the posChange
     */
    public int getPosChange() {
        return posChange;
    }

    /**
     * @return the posSet
     */
    public int getPosSet() {
        return posSet;
    }
    
    public static CardMove findById(int id){
        CardMove card = null;
        
        for(CardMove i : deckCardMove){
            if(i.getId() == id){
                card = i;
            }
        }   
        return card;
        // Throw idNotFoundException?
    }
}
