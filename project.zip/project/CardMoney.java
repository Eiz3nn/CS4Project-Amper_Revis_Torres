package project;

import java.util.ArrayList;

public class CardMoney extends Card {
    private int moneyChange;
    private static ArrayList<CardMoney> deckCardMoney = new ArrayList<CardMoney>();
    private boolean affectsAllOtherPlayers;
    
    public CardMoney(String d, String e, String c, int i, int m, boolean a){
        super(d,e,c,"cardmoney",i);
        moneyChange = m;
        affectsAllOtherPlayers = a;      
        deckCardMoney.add(this);
        
    }

    /**
     * @return the moneyGive
     */
    public int getMoneyChange() {
        return moneyChange;
    }
    
    /**
     * @return the affectsAllOtherPlayers
     */
    public boolean isAffectsAllOtherPlayers() {
        return affectsAllOtherPlayers;
    }
    
    public static CardMoney findById(int id){
        
        for(CardMoney i : deckCardMoney){
            if(i.getId() == id){
                return i;
            }
        }   
        return null;
        // Throw idNotFoundException?
    }

    
}
