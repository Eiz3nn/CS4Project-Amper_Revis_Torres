package project;

import java.util.ArrayList;

public class Board {
    private ArrayList<Tile> tiles = new ArrayList<Tile>();
    private ArrayList<Player> players = new ArrayList<Player>();
    private ArrayList<Property> properties = new ArrayList<Property>();
    private int noOfTiles;
   
    public Board(ArrayList<Tile> t, ArrayList<Player> p){
        tiles = t;
        players = p;
        noOfTiles = t.size();
    }
    
    public Board(ArrayList<Tile> t){
        tiles = t;
        noOfTiles = t.size();
    }
    
    public Board(){ noOfTiles = 0; }
        

    /**
     * @return the tiles
     */
    public ArrayList<Tile> getTiles() {
        return tiles;
    }

    /**
     * @return the players
     */
    public ArrayList<Player> getPlayers() {
        return players;
    }
    
    public ArrayList<Property> getProperties() {
        return properties;
    }

    public void addPlayer(Player p){
        players.add(p);
    }
    
    public void removePlayer(Player p){ 
        players.remove(p);
    }
    
    public void addTile(Property t){
        tiles.add(t);
        properties.add(t);
        noOfTiles++;
        t.setPosition(noOfTiles-1);
    }
    
    public void addTile(Tile t){
        tiles.add(t);
        noOfTiles++;
        t.setPosition(noOfTiles-1);
        
    }
    
    public Property propertyFindByPos(int p){
        Property n = null;
        for(Property i : properties){
            if(i.getPosition() == p){
                n = i;
            }
        }
        return n;
    }
    
    

    
    
        
}
