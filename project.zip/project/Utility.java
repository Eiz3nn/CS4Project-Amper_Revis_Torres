package project;

public class Utility extends Property{
    private int commonOwners, rollMultiplier;
    
    public Utility(String n, int i, int v, String s){
        super(n, "utility", i, v, s);
        
    }
}
