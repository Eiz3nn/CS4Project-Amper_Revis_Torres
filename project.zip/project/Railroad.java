package project;

public class Railroad extends Property{
    private int commonOwners, rentMultiplier;
    
    public Railroad(String n, int i, int v, String s){
        super(n, "railroad", i, v, s);
        
    }
}
