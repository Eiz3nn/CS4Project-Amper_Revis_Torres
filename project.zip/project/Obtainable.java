package project;

public interface Obtainable {
    
    void addToInventory(Player p);
    
}
