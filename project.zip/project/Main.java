package project;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
       
        Scanner scanner = new Scanner(System.in);
        String input;
        
        System.out.println("PLEASE READ BEFORE STARTING THE PROGRAM");
        System.out.println("To simulate the scenarios, please enter the following for each prompt:");
        System.out.println("  Prompt 1: \"1\"  (roll dice)");
        System.out.println("  Prompt 2: \"y\"  (purchase property)");
        System.out.println("  Prompt 3: \"8\"  (end turn)");
        System.out.println("  Prompt 4: \"1\"  (roll dice)");
        System.out.println("  Prompt 5: \"8\"  (end turn)");
        System.out.println("  Prompt 5: \"1\"  (roll dice)");
        System.out.println("  Prompt 5: \"8\"  (end turn)");
        
        System.out.println("\nAfter the scenarios are completed, you may terminate the program.\n\n");      
        
        System.out.println("Initializing board...");


        // Creating tiles
        Tile tile0 = new Tile("GO","go");    
        Property tile1 = new Colored("Ajisakki",2,50,"yellow",10);
        Tile tile2 = new Tile("Lunch Period","community");
        Property tile3 = new Colored("Back Lobby",5,70,"yellow",20);
        Tile tile4 = new Tile("Late Tax","inc");
        Property tile5 = new Railroad("Hallway",25,200,"common area");
        Property tile6 = new Colored("Chem Unit",7,90,"amber",20);
        Tile tile7 = new Tile("Study Period","chance");
        Property tile8 = new Colored("Bio Unit",9,100,"amber",30);
        Property tile9 = new Colored("Res Unit",10,110,"amber",40);
        Tile tile10 = new Tile ("Discipline Office", "free");              
        Property tile11 = new Colored("Library",13,140,"orange",40);
        Property tile12 = new Utility("Classrooms",150,120,"utility");
        Property tile13 = new Colored("GCU",13,140,"orange",50);
        Property tile14 = new Colored("Humanities Faculty",14,160,"orange",60);
        Property tile15 = new Railroad("Pavement",25,200,"common area");
        Property tile16 = new Colored("Learning Center",15,180,"black",60);
        Tile tile17 = new Tile("Lunch Period","community");
        Property tile18 = new Colored("3F Auditorium",15,180,"black",70);
        Property tile19 = new Colored("Math Faculty",16,190,"black",80);
        Tile tile20 = new Tile("Gym Parking","free");        
        Property tile21 = new Colored("Basketball Court",17,210,"navy",80);
        Tile tile22 = new Tile("Study Period","chance");
        Property tile23 = new Colored("Gym",18,230,"navy",90);
        Property tile24 = new Colored("Pool",20,240,"navy",90);
        Property tile25 = new Railroad("Corridor",25,200,"common area"); 
        Property tile26 = new Colored("Front Lobby",21,250,"gray",100);
        Property tile27 = new Colored("Admin Bldg",23,270,"gray",110);
        Property tile28 = new Utility("Labs",150,120,"utility");
        Property tile29 = new Colored("Gate 1",24,280,"gray",110);
        Tile tile30 = new Tile("Go to Disciplinary Office","jail");   
        Property tile31 = new Colored("ASTB Hall",25,290,"cyan",130);
        Property tile32 = new Colored("CS Unit",26,300,"cyan",140);
        Tile tile33 = new Tile("Lunch Period","community");
        Property tile34 = new Colored("Physics Unit",27,320,"cyan",160);
        Property tile35 = new Railroad("Stairwell",25,200,"common area"); 
        Tile tile36 = new Tile("Study Period","chance");
        Property tile37 = new Colored("Kalachuchi Lane",37,370,"blue",170);
        Tile tile38 = new Tile("Absent Tax","super");
        Property tile39 = new Colored("Field",60,450,"blue",190);

        Board b1 = new Board();
        
        b1.addTile(tile0);
        b1.addTile(tile1); //property
        b1.addTile(tile2);
        b1.addTile(tile3); //property
        b1.addTile(tile4);
        b1.addTile(tile5); //property
        b1.addTile(tile6); //property
        b1.addTile(tile7);
        b1.addTile(tile8); //property
        b1.addTile(tile9); //property
        b1.addTile(tile10);
        b1.addTile(tile11); //property
        b1.addTile(tile12); //property
        b1.addTile(tile13); //property
        b1.addTile(tile14); //property
        b1.addTile(tile15); //property
        b1.addTile(tile16); //property
        b1.addTile(tile17);
        b1.addTile(tile18); //property
        b1.addTile(tile19); //property
        b1.addTile(tile20);
        b1.addTile(tile21); //property
        b1.addTile(tile22);
        b1.addTile(tile23); //property
        b1.addTile(tile24); //property
        b1.addTile(tile25); //property
        b1.addTile(tile26); //property
        b1.addTile(tile27); //property
        b1.addTile(tile28); //property
        b1.addTile(tile29); //property
        b1.addTile(tile30);
        b1.addTile(tile31); //property
        b1.addTile(tile32); //property
        b1.addTile(tile33);
        b1.addTile(tile34); //property
        b1.addTile(tile35); //property
        b1.addTile(tile36);
        b1.addTile(tile37); //property
        b1.addTile(tile38);
        b1.addTile(tile39); //property
                      
        System.out.println("Initializing cards...");
        
        Card c1 = new CardMoney("A cat snatched your lunch!","You lost 10 PhP","community",0,-10,false);
        
        System.out.println("Initializing players...");

        Player p1 = new Player("Shawn",b1);
        Player p2 = new Player("Gio",b1);
        Player p3 = new Player("Eizen",b1);
       
        boolean valid = false;
        
        System.out.println("STARTING PROGRAM\n\n");
        
        System.out.println("WELCOME TO MONOPOLY: PISAY EDITION\n");
        System.out.println("Players:");
        for(Player i : b1.getPlayers()){
            System.out.printf("P%d: %s\n",b1.getPlayers().indexOf(i)+1,i.getName());
        }
        System.out.println("\nStarting game...\n\n");
       
        while(b1.getPlayers().size()>1){
            
            for(Player i : b1.getPlayers()){    
                
                System.out.printf("It is %s's turn\n\n", i.getName());
                i.startTurn();
                
                do {
                    System.out.println("Would you like to do any actions?");
                    System.out.println("Choices: ");
                    System.out.println("1 - Roll");
                    System.out.println("2 - View inventory");
                    System.out.println("3 - Buy houses");
                    System.out.println("4 - Sell houses");
                    System.out.println("5 - Mortgage properties");
                    System.out.println("6 - Unmortgage properties");
                    System.out.println("7 - Trade");
                    System.out.println("8 - End turn\n");

                    System.out.print("> ");
                    input = scanner.nextLine();
                
                    switch(input){
                        
                        case "1":
                            
                            /*
                            
                            [ NOTE ]
                            
                            Supposedly, we would be using the code below to move
                            the player around the board:
                            
                                i.move(i.roll());
                            
                            However, instead of basing the movement off a random 
                            roll, we will guarantee the player to move to a 
                            property to demonstrate the scenarios for the 
                            project.
                            
                            Also, each player in the program will be 
                            demonstrating a scenario:
                            
                              - Player "Shawn" will demonstrate scenario 1
                              - Player "Gio" will demonstrate scenario 2
                              - Player "Eizen" will demonstrate scenario 3
                            
                            */
                            
                            switch(i.getName()){
                                case "Shawn": i.move(6); break; // scenario 1
                                case "Gio": i.move(6); break;   // scenario 2
                                case "Eizen": i.move(2); break; // scenario 3
                            }
                             
                            System.out.printf("\nYou arrived at %s, located at tile %d.\n",i.getCurrentTile().getName(),b1.getTiles().indexOf(i.getCurrentTile()));
                                              
                            if(i.getCurrentTile().getType() == "colored" || i.getCurrentTile().getType() == "railroad" || i.getCurrentTile().getType() == "utility"){

                                if(i.getCurrentProperty().getOwner() == null){ 
                                    
                                    /* 
                                    
                                    [ SCENARIO 1 ]

                                    Shawn will simulate buying a property.
                                    
                                    Shawn will collect rent from players landing
                                    on his property.
                                    
                                    */
                                    
                                    while(!valid) {
                                    
                                    System.out.println("Property is not yet owned. Would you like to purchase this property?");
                                    System.out.printf("Property costs %d PhP\n", b1.propertyFindByPos(i.getPosition()).getValue());
                                    System.out.print("(y/n): "); // Shawn will input "y"
                                    input = scanner.nextLine();

                                    
                                        switch(input){
                                            case "y":
                                                i.buy(i.getCurrentProperty());
                                                System.out.printf("\nProperty %s was successfully bought.\n\n", i.getCurrentProperty().getName());
                                                valid = true;
                                                break;

                                            case "n":
                                                System.out.printf("\nProperty %s was not bought!\n\n", i.getCurrentProperty().getName());
                                                valid = true;
                                                break;

                                            default:
                                                System.out.println("\nInvalid input. Please try again.\n\n");
                                                valid = false;
                                        }
                                    }
                                    valid = false;
                                } else {
                                    /*
                                    
                                    [ SCENARIO 2 ]
                                    
                                    Gio will simulate landing on an owned property.
                                    
                                    Gio will pay the owner of the property.                                    
                                    
                                    */
                                    
                                    i.pay(i.getCurrentProperty().getOwner(),i.getCurrentProperty().getRent());
                                    System.out.printf("Property \"%s\" is already owned by %s.\n",i.getCurrentProperty().getName(),i.getCurrentProperty().getOwner().getName());
                                    System.out.printf("%s paid %s %d PhP for renting %s!\n\n",i.getName(),i.getCurrentProperty().getOwner().getName(),i.getCurrentProperty().getRent(),i.getCurrentProperty().getName());
                                }

                            }

                            else if(i.getCurrentTile().getType() == "chance"){
                                System.out.println("\n[ CHANCE CARD ]\n");
                                Card chance = i.drawCard("chance");
                                boolean isGetOutOfJailCard = false;
                                
                                if(chance.getType() == "cardjail"){
                                    if(CardJail.findById(chance.getId()).isGetOutOfJailCard()){
                                        isGetOutOfJailCard = true;
                                    } 
                                } 
                                
                                if(!isGetOutOfJailCard){
                                    i.useCard(chance);
                                    System.out.println(chance.getDescription());
                                    System.out.println(chance.getEffect());
                                    System.out.println();
                                }
                                 
                            }

                            else if(i.getCurrentTile().getType() == "community"){
                                
                                /*
                                
                                [ SCENARIO 3 ]
                                
                                Eizen will simulate drawing a random card.
                                
                                Cards will affect the player's stats. May have
                                positive or negative effects.
                                
                                */
                                
                                
                                System.out.println("\n[ COMMUNITY CHEST CARD ]\n");
                                Card community = i.drawCard("community");
                                boolean isGetOutOfJailCard = false;
                                
                                if(community.getType() == "cardjail"){
                                    if(CardJail.findById(community.getId()).isGetOutOfJailCard()){
                                        isGetOutOfJailCard = true;
                                    } 
                                } 
                                
                                if(!isGetOutOfJailCard){
                                    i.useCard(community);
                                    System.out.println(community.getDescription());
                                    System.out.println(community.getEffect());
                                    System.out.println();
                                }
                            }

                            else if(i.getCurrentTile().getType() == "free"){
                                //do nothing
                            }

                            else if(i.getCurrentTile().getType() == "income"){
                                i.tax(100);
                            }

                            else if(i.getCurrentTile().getType() == "super"){
                                i.tax(200);
                            }

                            else if(i.getCurrentTile().getType() == "jail"){
                                i.goToJail();
                                i.endTurn();
                            }

                            else {
                                System.out.printf("Invalid input."); 
                            }                                          
                            break;

                        case "2":
                            break;
                            
                        case "3":
                            break;

                        case "4":
                            break;

                        case "5":
                            break;

                        case "6":
                            break;
                              
                        case "7": 

                        case "8":
                            i.endTurn();
                            System.out.printf("\n%s has ended their turn.\n\n", i.getName());
                            break;
                            
                        default:
                            // Throw invalidActionException
                    }

                } while(i.isInTurn());
                
            }
               
        }
    }
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       

        
    /* 
        < FORMAT > 

      Property e tile = new Colored(name,initialRent,value,setName,houseValue);
      Propertyle tile = new Railroad(name,initialRent,value,setName,rentMultiplier);
      Property t tile = new Utility(name,initialRent,value,setName,rollMultiplier);
        Tile tile = new Tile(name,type);
    */  
    
    
}
